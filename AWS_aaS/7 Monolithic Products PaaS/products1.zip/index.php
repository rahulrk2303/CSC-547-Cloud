<h2>Welcome to the Web Store!</h2>
Navigate to the <a href="/products.php">products page</a> to buy products.